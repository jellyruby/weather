# weather_bot
날씨봇
------

### 기상청 OPEN API를 이용한 날씨 알리미

# 구현 예정 기능

### 1. KAKAO Talk bot 기능
### 2. 기상청 OPEN API를 이용한 날씨 알리미 https://data.kma.go.kr/cmmn/main.do
### 3. 위 두가지 기능 관리를 위한 Web 페이지 + 간단한 게시판

# 기술 스택
 
## 백엔드
#### nodejs
#### php


## 프론트엔드
#### HTML
#### CSS
#### JS
#### jQuery
#### --- 이후 도입예정 ---

#### React
#### svelte


## DB
#### mongo DB


## devops
#### github
#### AWS










